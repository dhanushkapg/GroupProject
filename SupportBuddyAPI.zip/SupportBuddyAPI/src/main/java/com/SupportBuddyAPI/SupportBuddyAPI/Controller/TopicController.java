package com.SupportBuddyAPI.SupportBuddyAPI.Controller;

import com.SupportBuddyAPI.SupportBuddyAPI.entity.Topic;
import com.SupportBuddyAPI.SupportBuddyAPI.service.TopicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/topic")
public class TopicController {

  @Autowired
  private TopicService topicService;

  @PostMapping("/add")
   public String addTopic(@RequestBody Topic topic)
  {
      topicService.addTopic(topic);
      return "Topic Insert Successfully";
  }

  @GetMapping("/getTopic")
    public List<Topic>getTopic(){
      return topicService.getTopic();
  }

}
