package com.SupportBuddyAPI.SupportBuddyAPI.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Topic {

 /* create table entities here*/

    @Id
    @GeneratedValue
    private Integer id;
    private String topic_name;


}
