package com.SupportBuddyAPI.SupportBuddyAPI.service;

import com.SupportBuddyAPI.SupportBuddyAPI.entity.Topic;

import java.util.List;

public interface TopicService {
    void addTopic(Topic topic);

    List<Topic> getTopic();
}
