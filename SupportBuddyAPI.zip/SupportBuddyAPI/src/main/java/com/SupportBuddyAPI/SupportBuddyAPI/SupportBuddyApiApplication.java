package com.SupportBuddyAPI.SupportBuddyAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupportBuddyApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupportBuddyApiApplication.class, args);
	}

}
