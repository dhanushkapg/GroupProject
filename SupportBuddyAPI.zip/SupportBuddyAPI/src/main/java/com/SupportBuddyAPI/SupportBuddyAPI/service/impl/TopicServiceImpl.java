package com.SupportBuddyAPI.SupportBuddyAPI.service.impl;

import com.SupportBuddyAPI.SupportBuddyAPI.entity.Topic;
import com.SupportBuddyAPI.SupportBuddyAPI.repository.TopicRepository;
import com.SupportBuddyAPI.SupportBuddyAPI.service.TopicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TopicServiceImpl implements TopicService {

    @Autowired
    private TopicRepository topicRepository;
    @Override
    public void addTopic(Topic topic) {
        topicRepository.save(topic);

    }

    @Override
    public List<Topic> getTopic() {
        return topicRepository.findAll();
    }
}
