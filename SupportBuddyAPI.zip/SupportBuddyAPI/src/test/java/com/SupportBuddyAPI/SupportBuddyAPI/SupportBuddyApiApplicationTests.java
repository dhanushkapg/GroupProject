package com.SupportBuddyAPI.SupportBuddyAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupportBuddyApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
