package com.SupportBuddyAPI.SupportBuddyAPI.Controller;

import com.SupportBuddyAPI.SupportBuddyAPI.entity.Answer;
import com.SupportBuddyAPI.SupportBuddyAPI.entity.Question;
import com.SupportBuddyAPI.SupportBuddyAPI.service.AnswerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/Answer")
public class AnswerController {
    @Autowired
    private AnswerService answerService;

    @GetMapping("/getAnswerByQID/{i}")
    public List<Answer> fetchController(@PathVariable String i)
    {
        return answerService.fetchUsingQID(i);
    }
}
