package com.SupportBuddyAPI.SupportBuddyAPI.Controller;

import com.SupportBuddyAPI.SupportBuddyAPI.entity.Model;
import com.SupportBuddyAPI.SupportBuddyAPI.service.impl.ModelServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ModelController {
    @Autowired
    private ModelServiceImpl modelService;

    @PostMapping("/addRate")
    public Model postDetails(@RequestBody Model model)
    {
         System.out.println(model.getModel());
         System.out.println(model.getId());
         System.out.println(model.getRate());
         return modelService.saveRate(model);
         //return "Insert Successfully";
    }
}
