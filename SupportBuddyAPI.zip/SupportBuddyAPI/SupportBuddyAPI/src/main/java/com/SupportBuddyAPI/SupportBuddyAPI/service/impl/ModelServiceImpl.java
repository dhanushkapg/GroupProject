package com.SupportBuddyAPI.SupportBuddyAPI.service.impl;

import com.SupportBuddyAPI.SupportBuddyAPI.entity.Model;
import com.SupportBuddyAPI.SupportBuddyAPI.repository.ModelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ModelServiceImpl {
    @Autowired
    private ModelRepository modelRepository;

    public Model saveRate(Model model){
        System.out.println(model.getModel());
        System.out.println("save");
        return  modelRepository.save(model);
        //System.out.println(model.getModel());
    }

}
