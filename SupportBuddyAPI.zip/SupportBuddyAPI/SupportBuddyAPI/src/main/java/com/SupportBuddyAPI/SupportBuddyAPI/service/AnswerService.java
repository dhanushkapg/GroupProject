package com.SupportBuddyAPI.SupportBuddyAPI.service;

import com.SupportBuddyAPI.SupportBuddyAPI.entity.Answer;

import java.util.List;

public interface AnswerService {
    List<Answer> fetchUsingQID(String i);
}
