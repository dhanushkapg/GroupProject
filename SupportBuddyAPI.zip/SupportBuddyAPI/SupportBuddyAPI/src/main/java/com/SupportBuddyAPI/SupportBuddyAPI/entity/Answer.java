package com.SupportBuddyAPI.SupportBuddyAPI.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "answer")



public class Answer {
    @Column(name = "QuestionID")

    private String QuestionID;

    @Id
    private String ModelID;

    private String Manswer;


}
