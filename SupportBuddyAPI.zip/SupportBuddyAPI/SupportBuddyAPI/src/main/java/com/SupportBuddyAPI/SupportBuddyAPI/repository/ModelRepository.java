package com.SupportBuddyAPI.SupportBuddyAPI.repository;

import com.SupportBuddyAPI.SupportBuddyAPI.entity.Model;
import org.springframework.boot.Banner;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ModelRepository extends JpaRepository<Model,Integer> {

}
