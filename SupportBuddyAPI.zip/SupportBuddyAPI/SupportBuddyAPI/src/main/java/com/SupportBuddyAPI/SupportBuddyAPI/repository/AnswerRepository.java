package com.SupportBuddyAPI.SupportBuddyAPI.repository;
import java.util.List;
import com.SupportBuddyAPI.SupportBuddyAPI.entity.Answer;
import com.SupportBuddyAPI.SupportBuddyAPI.entity.Question;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnswerRepository extends JpaRepository<Answer,String> {

    @Query(value = "SELECT * FROM answer where QuestionID=:val",nativeQuery = true)
    public List<Answer> fetchUsingQID(@Param("val") String i);
}
