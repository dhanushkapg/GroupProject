package com.SupportBuddyAPI.SupportBuddyAPI.service;

import com.SupportBuddyAPI.SupportBuddyAPI.entity.Question;

import java.util.List;
import java.util.Optional;


public interface QuestionService {
    List<Question>  fetchUsingID(int i) ;


    List<Question> getQuestion();




}
