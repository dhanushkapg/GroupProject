package com.SupportBuddyAPI.SupportBuddyAPI.repository;
import java.util.List;
import com.SupportBuddyAPI.SupportBuddyAPI.entity.Question;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface QuestionRepository extends JpaRepository<Question,Integer> {
   // List<Question> findByid(Integer id);

  @Query(value = "SELECT * FROM question where id=:val",nativeQuery = true)

  //public List<Question> fetchAll();
  public List<Question> fetchUsingID(@Param("val") Integer i);

}
