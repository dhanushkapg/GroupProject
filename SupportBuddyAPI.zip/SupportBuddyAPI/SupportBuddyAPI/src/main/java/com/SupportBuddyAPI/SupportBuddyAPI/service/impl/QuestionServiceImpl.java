package com.SupportBuddyAPI.SupportBuddyAPI.service.impl;

import com.SupportBuddyAPI.SupportBuddyAPI.entity.Question;
import com.SupportBuddyAPI.SupportBuddyAPI.repository.QuestionRepository;
import com.SupportBuddyAPI.SupportBuddyAPI.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
public class QuestionServiceImpl implements QuestionService {
    @Autowired
    private QuestionRepository questionRepository;
  //  @Override
    //public List<Question> getQuestion() {
        //return questionRepository.findAll();
    //}

    @Override
    public List<Question> getQuestion() {
        return questionRepository.findAll();
    }



public List<Question> fetchUsingID(int i)
{
    return questionRepository.fetchUsingID(i);
}



}


