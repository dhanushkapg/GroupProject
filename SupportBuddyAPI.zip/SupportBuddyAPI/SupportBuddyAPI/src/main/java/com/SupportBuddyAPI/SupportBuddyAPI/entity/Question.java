package com.SupportBuddyAPI.SupportBuddyAPI.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "question")
@NoArgsConstructor
@AllArgsConstructor
public class Question {


    @Column(name = "id")
    private Integer id;

    @Id
    private String Q_id;

    private String Question;

}
