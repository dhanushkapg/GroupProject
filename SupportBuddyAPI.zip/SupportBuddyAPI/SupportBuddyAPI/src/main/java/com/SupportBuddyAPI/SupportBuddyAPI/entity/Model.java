package com.SupportBuddyAPI.SupportBuddyAPI.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name="model")
@NoArgsConstructor
@AllArgsConstructor
public class Model {
    @Id
    @GeneratedValue
    @Column(name="ID")
    private int id;

    @Column(name = "ModelID")
    private String model;

    @Column(name="Rate")
    private int rate;


}
