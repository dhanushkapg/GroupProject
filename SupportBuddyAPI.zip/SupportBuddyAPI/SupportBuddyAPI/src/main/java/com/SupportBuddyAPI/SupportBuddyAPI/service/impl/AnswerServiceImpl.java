package com.SupportBuddyAPI.SupportBuddyAPI.service.impl;

import com.SupportBuddyAPI.SupportBuddyAPI.entity.Answer;
import com.SupportBuddyAPI.SupportBuddyAPI.entity.Question;
import com.SupportBuddyAPI.SupportBuddyAPI.repository.AnswerRepository;
import com.SupportBuddyAPI.SupportBuddyAPI.repository.QuestionRepository;
import com.SupportBuddyAPI.SupportBuddyAPI.service.AnswerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class AnswerServiceImpl implements AnswerService {
@Autowired
private AnswerRepository answerRepository;

    @Override
    public List<Answer> fetchUsingQID(String i) {
        return answerRepository.fetchUsingQID(i);
    }
}
